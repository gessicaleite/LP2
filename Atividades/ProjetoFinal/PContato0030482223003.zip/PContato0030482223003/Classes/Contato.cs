﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PContato0030482223003.Classes
{
    internal class Contato
    {
    }
}
